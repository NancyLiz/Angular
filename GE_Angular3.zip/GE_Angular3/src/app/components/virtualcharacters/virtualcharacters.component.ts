import { Component } from '@angular/core';

@Component({
  selector: 'virtual',
  templateUrl: './virtualcharacters.component.html',
  styleUrls: ['./virtualcharacters.component.css']
})
export class VirtualComponent {
  //title = 'Prueba';

}