import { Component } from '@angular/core';

@Component({
  selector: 'sagitta',
  templateUrl: './sagitta.component.html',
  styleUrls: ['./sagitta.component.css']
})
export class SagittaComponent {
  //title = 'Prueba';

}