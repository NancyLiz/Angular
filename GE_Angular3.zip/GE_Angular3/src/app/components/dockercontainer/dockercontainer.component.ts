import { Component } from '@angular/core';

@Component({
  selector: 'dockercontainer',
  templateUrl: './dockercontainer.component.html',
  styleUrls: ['./dockercontainer.component.css']
})
export class DockerComponent {
  //title = 'Prueba';

}