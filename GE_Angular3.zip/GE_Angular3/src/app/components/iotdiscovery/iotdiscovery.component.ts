import { Component } from '@angular/core';

@Component({
  selector: 'discovery',
  templateUrl: './iotdiscovery.component.html',
  styleUrls: ['./iotdiscovery.component.css']
})
export class DiscoveryComponent {
  //title = 'Prueba';

}