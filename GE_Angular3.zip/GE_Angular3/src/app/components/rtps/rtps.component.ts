import { Component } from '@angular/core';

@Component({
  selector: 'rtps',
  templateUrl: './rtps.component.html',
  styleUrls: ['./rtps.component.css']
})
export class RtpsComponent {
  //title = 'Prueba';

}