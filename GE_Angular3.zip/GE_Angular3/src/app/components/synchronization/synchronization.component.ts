import { Component } from '@angular/core';

@Component({
  selector: 'synchronization',
  templateUrl: './synchronization.component.html',
  styleUrls: ['./synchronization.component.css']
})
export class SynchronizationComponent {
  //title = 'Prueba';

}