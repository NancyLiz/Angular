import { Component } from '@angular/core';

@Component({
  selector: 'keyrock',
  templateUrl: './keyrock.component.html',
  styleUrls: ['./keyrock.component.css']
})
export class KeyrockComponent {
  //title = 'Prueba';

}