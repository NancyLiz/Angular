import { Component } from '@angular/core';

@Component({
  selector: 'rendering',
  templateUrl: './cloudrendering.component.html',
  styleUrls: ['./cloudrendering.component.css']
})
export class RenderingComponent {
  //title = 'Prueba';

}