import { Component } from '@angular/core';

@Component({
  selector: 'cosmos',
  templateUrl: './cosmos.component.html',
  styleUrls: ['./cosmos.component.css']
})
export class CosmosComponent {
  //title = 'Prueba';

}