import { Component } from '@angular/core';

@Component({
  selector: 'ckan',
  templateUrl: './ckan.component.html',
  styleUrls: ['./ckan.component.css']
})
export class CkanComponent {
  //title = 'Prueba';

}