import { Component } from '@angular/core';

@Component({
  selector: 'sinfonier',
  templateUrl: './sinfonier.component.html',
  styleUrls: ['./sinfonier.component.css']
})
export class SinfonierComponent {
  //title = 'Prueba';

}