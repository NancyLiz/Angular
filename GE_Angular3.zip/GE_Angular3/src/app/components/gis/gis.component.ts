import { Component } from '@angular/core';

@Component({
  selector: 'gis',
  templateUrl: './gis.component.html',
  styleUrls: ['./gis.component.css']
})
export class GisComponent {
  //title = 'Prueba';

}