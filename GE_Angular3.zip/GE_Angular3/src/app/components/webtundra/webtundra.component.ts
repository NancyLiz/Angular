import { Component } from '@angular/core';

@Component({
  selector: 'tundra',
  templateUrl: './webtundra.component.html',
  styleUrls: ['./webtundra.component.css']
})
export class TundraComponent {
  //title = 'Prueba';

}