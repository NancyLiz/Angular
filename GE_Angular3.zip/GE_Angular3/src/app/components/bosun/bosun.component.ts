import { Component } from '@angular/core';

@Component({
  selector: 'bosun',
  templateUrl: './bosun.component.html',
  styleUrls: ['./bosun.component.css']
})
export class BosunComponent {
  //title = 'Prueba';

}