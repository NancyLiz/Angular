import { Component } from '@angular/core';

@Component({
  selector: 'cygnus',
  templateUrl: './cygnus.component.html',
  styleUrls: ['./cygnus.component.css']
})
export class CygnusComponent {
  //title = 'Prueba';

}