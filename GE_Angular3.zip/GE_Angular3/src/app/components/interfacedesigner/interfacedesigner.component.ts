import { Component } from '@angular/core';

@Component({
  selector: 'interface',
  templateUrl: './interfacedesigner.component.html',
  styleUrls: ['./interfacedesigner.component.css']
})
export class InterfaceComponent {
  //title = 'Prueba';

}