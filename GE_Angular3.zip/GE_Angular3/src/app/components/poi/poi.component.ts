import { Component } from '@angular/core';

@Component({
  selector: 'poi',
  templateUrl: './poi.component.html',
  styleUrls: ['./poi.component.css']
})
export class PoiComponent {
  //title = 'Prueba';

}