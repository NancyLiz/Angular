import { Component } from '@angular/core';

@Component({
  selector: 'xml3d',
  templateUrl: './xml3d.component.html',
  styleUrls: ['./xml3d.component.css']
})
export class Xml3dComponent {
  //title = 'Prueba';

}