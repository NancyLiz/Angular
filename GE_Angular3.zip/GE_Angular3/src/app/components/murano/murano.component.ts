import { Component } from '@angular/core';

@Component({
  selector: 'murano',
  templateUrl: './murano.component.html',
  styleUrls: ['./murano.component.css']
})
export class MuranoComponent {
  //title = 'Prueba';

}