import { Component } from '@angular/core';

@Component({
  selector: 'barra',
  templateUrl: './barra.component.html',
  styleUrls: ['./barra.component.css']
})
export class BarraComponent {
  //title = 'app works!';
}
