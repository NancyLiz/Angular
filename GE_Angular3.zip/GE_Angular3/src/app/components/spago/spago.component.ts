import { Component } from '@angular/core';

@Component({
  selector: 'spago',
  templateUrl: './spago.component.html',
  styleUrls: ['./spago.component.css']
})
export class SpagoComponent {
  //title = 'Prueba';

}