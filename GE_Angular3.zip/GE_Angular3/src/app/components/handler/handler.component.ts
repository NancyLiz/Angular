import { Component } from '@angular/core';

@Component({
  selector: 'handler',
  templateUrl: './handler.component.html',
  styleUrls: ['./handler.component.css']
})
export class HandlerComponent {
  //title = 'Prueba';

}