import { Component } from '@angular/core';

@Component({
  selector: 'proton',
  templateUrl: './proton.component.html',
  styleUrls: ['./proton.component.css']
})
export class ProtonComponent {
  //title = 'Prueba';

}