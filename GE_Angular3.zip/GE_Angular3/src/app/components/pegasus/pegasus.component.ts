import { Component } from '@angular/core';

@Component({
  selector: 'pegasus',
  templateUrl: './pegasus.component.html',
  styleUrls: ['./pegasus.component.css']
})
export class PegasusComponent {
  //title = 'Prueba';

}