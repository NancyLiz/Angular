import { Component } from '@angular/core';

@Component({
  selector: 'domibus',
  templateUrl: './domibus.component.html',
  styleUrls: ['./domibus.component.css']
})
export class DomibusComponent {
  //title = 'Prueba';

}