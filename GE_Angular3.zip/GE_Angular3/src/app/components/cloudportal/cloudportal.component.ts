import { Component } from '@angular/core';

@Component({
  selector: 'cloudportal',
  templateUrl: './cloudportal.component.html',
  styleUrls: ['./cloudportal.component.css']
})
export class CloudportalComponent {
  //title = 'Prueba';

}