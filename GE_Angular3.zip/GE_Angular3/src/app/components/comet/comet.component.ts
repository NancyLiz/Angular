import { Component } from '@angular/core';

@Component({
  selector: 'comet',
  templateUrl: './comet.component.html',
  styleUrls: ['./comet.component.css']
})
export class CometComponent {
  //title = 'Prueba';

}