import { Component } from '@angular/core';

@Component({
  selector: 'idas',
  templateUrl: './idas.component.html',
  styleUrls: ['./idas.component.css']
})
export class IdasComponent {
  //title = 'Prueba';

}