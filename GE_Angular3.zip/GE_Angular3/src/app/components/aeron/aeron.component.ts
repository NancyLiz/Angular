import { Component } from '@angular/core';

@Component({
  selector: 'aeron',
  templateUrl: './aeron.component.html',
  styleUrls: ['./aeron.component.css']
})
export class AeronComponent {
  //title = 'Prueba';

}