import { Component } from '@angular/core';

@Component({
  selector: 'iaas',
  templateUrl: './iaas.component.html',
  styleUrls: ['./iaas.component.css']
})
export class IaasComponent {
  //title = 'Prueba';

}