import { Component } from '@angular/core';

@Component({
  selector: 'geoserver',
  templateUrl: './geoserver.component.html',
  styleUrls: ['./geoserver.component.css']
})
export class GeoserverComponent {
  //title = 'Prueba';

}