import { Component } from '@angular/core';

@Component({
  selector: 'biz',
  templateUrl: './biz.component.html',
  styleUrls: ['./biz.component.css']
})
export class BizComponent {
  //title = 'Prueba';

}