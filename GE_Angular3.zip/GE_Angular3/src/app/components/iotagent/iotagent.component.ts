import { Component } from '@angular/core';

@Component({
  selector: 'agent',
  templateUrl: './iotagent.component.html',
  styleUrls: ['./iotagent.component.css']
})
export class IotagentComponent {
  //title = 'Prueba';

}