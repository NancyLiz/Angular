import { BrowserModule } from '@angular/platform-browser';
import { NgModule, RenderComponentType } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {routing, appRoutingProviders} from './app.routing'

import {GeReportService} from'./services/ge-report.service'; //import GeReport service 
//Importación de cada uno de los componentes a utilizar indicando en que fichero se
//encuentran cada uno
import { AppComponent } from './app.component';
import { EjemploComponent } from './components/ejemplo/ejemplo.component';
import { MenuComponent } from './components/menu/menu.component';
import { OrionComponent } from './components/orion/orion.component';
import { WirecloudComponent } from './components/wirecloud/wirecloud.component';
import { KnowageComponent } from './components/knowage/knowage.component';
import { WilmaComponent } from './components/wilma/wilma.component';
import { KeyrockComponent } from './components/keyrock/keyrock.component';
import { AuthzforceComponent } from './components/authzforce/authzforce.component';
import { AeonComponent } from './components/aeon/aeon.component';
import { BotonComponent } from './components/boton/boton.component';
import { CheckboxComponent } from './components/checkbox/checkbox.component';
import { Boton2Component } from './components/boton2/boton2.component';
import { GeReportComponent } from './components/ge-report/ge-report.component';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './components/home/home.component';
import { GeReportGComponent } from './components/ge-report-g/ge-report-g.component';
import { HelpComponent } from './components/help/help.component';
import { BarraComponent } from './components/barra/barra.component';
import { CkanComponent } from './components/ckan/ckan.component';
import { CosmosComponent } from './components/cosmos/cosmos.component';
import { IdasComponent } from './components/idas/idas.component';
import { BizComponent } from './components/biz/biz.component';
import { BosunComponent } from './components/bosun/bosun.component';
import { DomibusComponent } from './components/domibus/domibus.component';
import { AeronComponent } from './components/aeron/aeron.component';
import { InterfaceComponent } from './components/interfacedesigner/interfacedesigner.component';
import { RtpsComponent } from './components/rtps/rtps.component';
import { CometComponent } from './components/comet/comet.component';
import { CygnusComponent } from './components/cygnus/cygnus.component';
import { ProtonComponent } from './components/proton/proton.component';
import { DiscoveryComponent } from './components/iotdiscovery/iotdiscovery.component';
import { IotagentComponent } from './components/iotagent/iotagent.component';
import { RenderingComponent } from './components/cloudrendering/cloudrendering.component';
import { GisComponent } from './components/gis/gis.component';
import { Xml3dComponent } from './components/xml3d/xml3d.component';
import { VirtualAction } from 'rxjs/scheduler/VirtualTimeScheduler';
import { VirtualComponent } from './components/virtualcharacters/virtualcharacters.component';
import { SynchronizationComponent } from './components/synchronization/synchronization.component';
import { PoiComponent } from './components/poi/poi.component';
import { TundraComponent } from './components/webtundra/webtundra.component';
import { PrivacyComponent } from './components/privacy/privacy.component';
import { SpagoComponent } from './components/spago/spago.component';
import { MuranoComponent } from './components/murano/murano.component';
import { CloudportalComponent } from './components/cloudportal/cloudportal.component';
import { SagittaComponent } from './components/sagitta/sagitta.component';
import { PegasusComponent } from './components/pegasus/pegasus.component';
import { SinfonierComponent } from './components/sinfonier/sinfonier.component';
import { HandlerComponent } from './components/handler/handler.component';
import { GeoserverComponent } from './components/geoserver/geoserver.component';
import { IaasComponent } from './components/iaas/iaas.component';
import { DockerComponent } from './components/dockercontainer/dockercontainer.component';

//Se cargan los componentes
@NgModule({
  declarations: [
    AppComponent,
    EjemploComponent,
    MenuComponent,
    OrionComponent,
    WirecloudComponent,
    KnowageComponent,
    WilmaComponent,
    KeyrockComponent,
    AuthzforceComponent,
    AeonComponent,
    BotonComponent,
    CheckboxComponent,
    Boton2Component,
    GeReportComponent,
    HomeComponent,
    GeReportGComponent,
    HelpComponent,
    BarraComponent,
    CkanComponent,
    CosmosComponent,
    IdasComponent,
    BizComponent,
    BosunComponent,
    DomibusComponent,
    AeronComponent,
    InterfaceComponent,
    RtpsComponent,
    CometComponent,
    CygnusComponent,
    ProtonComponent,
    DiscoveryComponent,
    IotagentComponent,
    RenderingComponent,
    GisComponent,
    Xml3dComponent,
    VirtualComponent,
    SynchronizationComponent,
    PoiComponent,
    TundraComponent,
    PrivacyComponent,
    SpagoComponent,
    MuranoComponent,
    CloudportalComponent,
    SagittaComponent,
    PegasusComponent,
    SinfonierComponent,
    HandlerComponent,
    GeoserverComponent,
    IaasComponent,
    DockerComponent,
  ], 
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing
  ],
  providers: [
    GeReportService,
    appRoutingProviders 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
