//Permite la creación de un componente e indica que esta en el paquete principal
// de angular
import { Component } from '@angular/core';
//Decorador con el que se define el componente
@Component({
  //Etiqueta final donde se carga el componente
  selector: 'proton',
  //Plantilla asociada al componente
  templateUrl: './proton.component.html',
  //Hoja de estilos asociada al componente
  styleUrls: ['./proton.component.css']
})
//Permite que la clase sea utilizada dentro de otro fichero
export class ProtonComponent {

}