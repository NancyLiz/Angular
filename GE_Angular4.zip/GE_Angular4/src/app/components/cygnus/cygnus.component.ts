//Permite la creación de un componente e indica que esta en el paquete principal
// de angular
import { Component } from '@angular/core';
//Decorador con el que se define el componente
@Component({
  //Etiqueta final donde se carga el componente
  selector: 'cygnus',
  //Plantilla asociada al componente
  templateUrl: './cygnus.component.html',
  //Hoja de estilos asociada al componente
  styleUrls: ['./cygnus.component.css']
})
//Permite que la clase sea utilizada dentro de otro fichero
export class CygnusComponent {
 
}