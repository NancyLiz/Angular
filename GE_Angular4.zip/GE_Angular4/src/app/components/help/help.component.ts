//Permite la creación de un componente e indica que esta en el paquete principal
// de angular
import { Component, OnInit } from '@angular/core';
//Decorador con el que se define el componente
@Component({
  //Etiqueta final donde se carga el componente
  selector: 'app-help',
  //Plantilla asociada al componente
  templateUrl: './help.component.html',
  //Hoja de estilos asociada al componente
  styleUrls: ['./help.component.css']
})
//Permite que la clase sea utilizada dentro de otro fichero
export class HelpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
