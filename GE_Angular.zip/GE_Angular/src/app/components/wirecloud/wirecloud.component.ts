import { Component } from '@angular/core';

@Component({
  selector: 'wirecloud',
  templateUrl: './wirecloud.component.html',
  styleUrls: ['./wirecloud.component.css']
})
export class WirecloudComponent {
  //title = 'Prueba';

}