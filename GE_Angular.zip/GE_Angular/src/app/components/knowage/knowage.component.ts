import { Component } from '@angular/core';

@Component({
  selector: 'knowage',
  templateUrl: './knowage.component.html',
  styleUrls: ['./knowage.component.css']
})
export class KnowageComponent {
  //title = 'Prueba';

}