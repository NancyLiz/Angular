import { Component } from '@angular/core';

@Component({
  selector: 'aeon',
  templateUrl: './aeon.component.html',
  styleUrls: ['./aeon.component.css']
})
export class AeonComponent {
  //title = 'Prueba';

}