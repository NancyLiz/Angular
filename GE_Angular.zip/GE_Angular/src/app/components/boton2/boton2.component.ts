import { Component } from '@angular/core';

@Component({
  selector: 'boton2',
  templateUrl: './boton2.component.html',
  styleUrls: ['./boton2.component.css']
})
export class Boton2Component {
  //title = 'Prueba';

}
