import { Component } from '@angular/core';

@Component({
  selector: 'authzforce',
  templateUrl: './authzforce.component.html',
  styleUrls: ['./authzforce.component.css']
})
export class AuthzforceComponent {
  //title = 'Prueba';

}